using UnityEngine;
using System.Collections;

public interface Ferr2D_IPath {
	void Build(bool aFullRebuild);
}