﻿using UnityEngine;
using System.Collections;

namespace Ferr {
	public interface IEdgeOverride {
		int EdgeOverride {get;}
	}
}
